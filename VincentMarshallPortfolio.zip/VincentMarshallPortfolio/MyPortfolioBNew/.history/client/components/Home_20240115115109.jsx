import BBG from '../src/assets/BBG.jpeg';
export default function Home() {
     return <>
     <section></section>
     <p>Hello World!</p>
     <img src={BBG} alt="profile" className="bbg" />

     </>
     }
    