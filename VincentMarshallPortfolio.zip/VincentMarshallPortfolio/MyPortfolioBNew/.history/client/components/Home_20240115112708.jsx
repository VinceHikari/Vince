import React from 'react';
import BBG from '../src/assets/BBG.jpeg';
export default function Home() {
     return (
          <div>
     <span className="hello">Hello World!</span>
     <span className="introduction">I am <span className="introName">Blessing Ajiboye</span>
     <br/> Website Designer<span/>
     </div>
     <img src={}>
     );
     }
    