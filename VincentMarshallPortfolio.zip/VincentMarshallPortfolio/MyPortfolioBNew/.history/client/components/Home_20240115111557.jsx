import React from 'react';
import football1 from '../src/assets/football1.jfif';
export default function Home() {
     return (
          <section id=></section>
     <p>Hello World!</p>
     );
     }
    